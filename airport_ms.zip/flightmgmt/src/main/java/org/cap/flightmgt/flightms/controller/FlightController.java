package org.cap.flightmgt.flightms.controller;

import org.cap.flightmgt.flightms.dto.FlightDto;
import org.cap.flightmgt.flightms.entities.Flight;
import org.cap.flightmgt.flightms.exceptions.FlightNotFoundException;
import org.cap.flightmgt.flightms.service.IFlightService;
import org.hibernate.annotations.common.util.impl.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import ch.qos.logback.classic.Logger;

import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.validation.ConstraintViolationException;
import javax.validation.Valid;

@RestController
@Validated
@RequestMapping("/flights")
public class FlightController {
	
	private static final org.jboss.logging.Logger Log = LoggerFactory.logger(FlightController.class);
    @Autowired
    private IFlightService service;

    
    @GetMapping
    public ResponseEntity<List<FlightDto>> fetchAll() {
        List<Flight> flight = service.viewAllFlight();
        List<FlightDto> list = convertFlight(flight);
        ResponseEntity<List<FlightDto>> response = new ResponseEntity<>(list, HttpStatus.OK);
        return response;
    }

    @PostMapping("/add")
    public ResponseEntity<FlightDto> book(@RequestBody @Valid FlightDto flightDto) {
            Flight flight  = converToFlight(flightDto);
                   flight =service.addFlight(flight);
                   FlightDto Dto=  convertFlight(flight);
        ResponseEntity<FlightDto> response = new ResponseEntity<>(Dto, HttpStatus.OK);
        return response;

    }
    
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Boolean> deleteFlight(@PathVariable("id") BigInteger flightNo) {
        boolean result = service.deleteFlight(flightNo);
        ResponseEntity respose = new ResponseEntity(result, HttpStatus.OK);
        return respose;
    }
    
    @GetMapping("/find/{id}")
    public ResponseEntity<FlightDto> findById(@PathVariable("id") BigInteger flightNo) {
    
        Flight flight = service.viewFlight(flightNo);
              FlightDto   flightDto = convertFlight(flight);
        ResponseEntity<FlightDto> response = new ResponseEntity<>(flightDto, HttpStatus.OK);
        return response;
    }
    
    @PutMapping("/update/{id}")
    public ResponseEntity<Boolean> updateFlight(@RequestBody Flight flight, @PathVariable BigInteger id) {

          	Flight flight1 = service.viewFlight(id);
          					flight.setFlightNumber(id);
          					service.modifyFlight(flight);
          	ResponseEntity  response = new ResponseEntity(true, HttpStatus.OK);
    		return response;
    }


    public  Flight converToFlight(FlightDto flightDto) {
		Flight flight = new Flight();
		flight.setFlightNumber(flightDto.getFlightNumber());
		flight.setFlightModel(flightDto.getFlightModel());
		flight.setCarrierName(flightDto.getCarrierName());
		flight.setSeatCapacity(flightDto.getSeatCapacity());
		return flight;
	}


    public List<FlightDto> convertFlight(List<Flight> flights) {
        List<FlightDto> list = new ArrayList<>();
        for (Flight flight : flights) {
        	FlightDto detailsDto = convertFlight(flight);
            list.add(detailsDto);
        }
        return list;
    }

    FlightDto convertFlight(Flight flight) {
        FlightDto detailsDto = new FlightDto();
        detailsDto.setCarrierName(flight.getCarrierName());
        detailsDto.setFlightModel(flight.getFlightModel());
        detailsDto.setFlightNumber(flight.getFlightNumber());
        detailsDto.setSeatCapacity(flight.getSeatCapacity());
        return detailsDto;
    }
    
    @PostConstruct
    public void addFlights() {
    	
    	Flight flight = new Flight();
    	flight.setFlightNumber(BigInteger.valueOf(100));
    	flight.setCarrierName("Airbus");
    	flight.setFlightModel("AS300");
    	flight.setSeatCapacity(200);
    	service.addFlight(flight);
    	
         flight = new Flight();
    	flight.setFlightNumber(BigInteger.valueOf(101));
    	flight.setCarrierName("Airbus");
    	flight.setFlightModel("AZ300");
    	flight.setSeatCapacity(250);
    	service.addFlight(flight);
    	
        flight = new Flight();
    	flight.setFlightNumber(BigInteger.valueOf(102));
    	flight.setCarrierName("Boeing");
    	flight.setFlightModel("BZ747");
    	flight.setSeatCapacity(220);
    	service.addFlight(flight);
    	
         flight = new Flight();
    	flight.setFlightNumber(BigInteger.valueOf(103));
    	flight.setCarrierName("Boeing");
    	flight.setFlightModel("BZ777");
    	flight.setSeatCapacity(200);
    	service.addFlight(flight);
    	
    	 flight = new Flight();
    	flight.setFlightNumber(BigInteger.valueOf(104));
    	flight.setCarrierName("Douglas");
    	flight.setFlightModel("DC300");
    	flight.setSeatCapacity(270);
    	service.addFlight(flight);
    	
        flight = new Flight();
    	flight.setFlightNumber(BigInteger.valueOf(105));
    	flight.setCarrierName("Douglas");
    	flight.setFlightModel("DZ307");
    	flight.setSeatCapacity(120);
    	service.addFlight(flight);
    	
        flight = new Flight();
    	flight.setFlightNumber(BigInteger.valueOf(106));
    	flight.setCarrierName("Airbus");
    	flight.setFlightModel("AB330");
    	flight.setSeatCapacity(188);
    	service.addFlight(flight);
    	
        flight = new Flight();
    	flight.setFlightNumber(BigInteger.valueOf(107));
    	flight.setCarrierName("Indigo");
    	flight.setFlightModel("AS333");
    	flight.setSeatCapacity(280);
    	service.addFlight(flight);
    	
    	 flight = new Flight();
    	flight.setFlightNumber(BigInteger.valueOf(108));
    	flight.setCarrierName("Air India");
    	flight.setFlightModel("BS497");
    	flight.setSeatCapacity(180);
    	service.addFlight(flight);
    	
         flight = new Flight();
    	flight.setFlightNumber(BigInteger.valueOf(109));
    	flight.setCarrierName("Indigo");
    	flight.setFlightModel("BZ309");
    	flight.setSeatCapacity(150);
    	service.addFlight(flight);
    	
        flight = new Flight();
    	flight.setFlightNumber(BigInteger.valueOf(110));
    	flight.setCarrierName("Air India");
    	flight.setFlightModel("BB440");
    	flight.setSeatCapacity(220);
    	service.addFlight(flight);
 
    }

    
    
   
    @ExceptionHandler(FlightNotFoundException.class)
    public ResponseEntity<String> handleEmployeeNotFound(FlightNotFoundException ex) {
        Log.error("Invalid Flight Code Exception ", ex);
        String msg = ex.getMessage();
        ResponseEntity<String> response = new ResponseEntity<>(msg, HttpStatus.NOT_FOUND);
        return response;
    }

    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<String> handleConstraintViolate(ConstraintViolationException ex) {
        Log.error("constraint violation ", ex);
        String msg = ex.getMessage();
        ResponseEntity<String> response = new ResponseEntity<>(msg, HttpStatus.BAD_REQUEST);
        return response;
    }

   
    @ExceptionHandler(Throwable.class)
    public ResponseEntity<String> handleAll(Throwable ex) {
        Log.error("Something went wrong ", ex);
        String msg = ex.getMessage();
        ResponseEntity<String> response = new ResponseEntity<>(msg, HttpStatus.INTERNAL_SERVER_ERROR);
        return response;
    }

}
